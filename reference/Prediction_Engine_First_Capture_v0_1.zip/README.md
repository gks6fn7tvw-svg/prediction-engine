# Prediction Engine: first public-data audit capture

Captured during the November 10, 2026 Honolulu design review (November 11 UTC). This is a one-off source and market-data audit. No recurring logger, prediction engine, forecasts, simulated orders or real orders were started.

## Contents

- Open-market discovery response envelopes for KXHIGHNY, KXHIGHCHI, KXHIGHMIA, KXHIGHDEN and KXHIGHLAX. Each includes request/receipt times, URL and structured response data. The embedded response hash refers to original received bytes before JSON reformatting; the package manifest hashes the saved envelope itself.
- Full public order-book batch responses for the six ranges in each city's November 11 daily-high event: 30 contract books across five underlying events, not 30 independent event outcomes. Separate metadata records identify request/receipt time, endpoint and the SHA-256 hash of the exact book-response file.
- An unauthenticated NOAA NBM archive listing and request metadata. It returned dated CONUS GRIB2 object keys for August 14, 2026. This is archive-existence evidence, not a verified complete training dataset.
- Browser source-audit notes and independent sample-size calculations. The notes are observations, not copies of a full report archive.
- A manifest of file sizes and hashes.

## Limits

Books were captured sequentially/asynchronously across requests, not as one atomic exchange snapshot, and not at each city's proposed prior-evening 6 p.m. cutoff. There is no one-second execution recheck in this capture. Displayed liquidity is not proof of a fill. Forecast input series and observing-station coordinates have not yet been captured or verified; this package cannot by itself train or evaluate the proposed model. No future outcomes, filled trades or profit are asserted. Do not include this capture in a confirmatory trial.

All requests were for public data and used no account credentials. A continuous forward recorder remains a future implementation task under the $0 additional-spending constraint.
