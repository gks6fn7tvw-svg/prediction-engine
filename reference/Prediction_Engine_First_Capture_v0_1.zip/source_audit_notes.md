# Source audit observations

Reviewed November 10, 2026 Pacific/Honolulu.

1. Public Kalshi series endpoints returned HTTP 200 for all five proposed series and named The Weather Company, linking to https://weather.com/kalshi. Open-market rules for November 11 named CLINYC, CLIMDW, CLIMIA, CLIDEN and CLILAX respectively. Coordinates and full measurement-day rules remain unaudited.
2. Direct browser inspection of https://weather.com/kalshi showed a Daily Climate table with Max (F), station/report IDs and Final statuses. The inspected menu offered November 6-9, 2026. Reports for November 6 and November 9 were viewed. This is not evidence of a complete multi-month or machine-readable archive.
3. The portal's source note attributes daily figures to NWS/NOAA official CLI reports, with CF6 as backup, and explains revisions when later reports change the applicable result. This supports a compatibility audit of older NWS labels; it does not prove they match the contract's exact settlement version.
4. Observed daily maxima, in degrees Fahrenheit, were: November 9: NYC 58, Chicago Midway 61, Miami 85, Denver 72, Los Angeles 86. November 6: NYC 70, Chicago Midway 48, Miami 86, Denver 60, Los Angeles 83. These are transcribed portal observations, not independently reconciled settlement labels.
5. NOAA NBM dated S3 objects were listed without authentication. Required forecast horizons, variables, completeness and release timing still need an audit.
6. Open-Meteo's official documentation distinguishes reanalysis, stitched forecasts, fixed-lead histories and individual forecast runs. The latter are appropriate candidates for fixed-cutoff reconstruction subject to publication-lag checks. Its pricing page distinguishes free evaluation/prototyping from paid commercial use. Production eligibility was not assumed.

No screenshots, user credentials or personal account data are included.
